from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from pydantic import BaseModel
from app.services import process_url_content, process_pdf_content, get_response
from app.storage import store_content

app = FastAPI()

class URLRequest(BaseModel):
    url: str

class ChatRequest(BaseModel):
    chat_id: str
    question: str

@app.post("/process_url")
async def process_url(request: URLRequest):
    content = process_url_content(request.url)
    print(content)
    if not content:
        raise HTTPException(status_code=400, detail="Failed to process URL")
    chat_id = store_content(content)
    return {"chat_id": chat_id, "message": "URL content processed and stored successfully."}

@app.post("/process_pdf")
async def process_pdf(file: UploadFile = File(...)):
    content = process_pdf_content(file.file)
    if not content:
        raise HTTPException(status_code=400, detail="Failed to process PDF")
    chat_id = store_content(content)
    return {"chat_id": chat_id, "message": "PDF content processed and stored successfully."}

@app.post("/chat")
async def chat(request: ChatRequest):
    response = get_response(request.chat_id, request.question)
    print(response)
    if not response:
        raise HTTPException(status_code=404, detail="No relevant response found.")
    return {"response": response}
